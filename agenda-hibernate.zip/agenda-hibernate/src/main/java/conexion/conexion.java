
package conexion;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 *
 * @author CamiloT
 */
public class conexion {
    
    private static conexion instancia=new conexion();
    private EntityManagerFactory fabrica;
    
    private conexion()
    {
        fabrica=Persistence.createEntityManagerFactory("com.mycompany_agenda-hibernate_jar_1.0-SNAPSHOTPU");
        
    }

    public static conexion getInstancia() {
        return instancia;
    }

    public EntityManagerFactory getFabrica() {
        return fabrica;
    }
    
}

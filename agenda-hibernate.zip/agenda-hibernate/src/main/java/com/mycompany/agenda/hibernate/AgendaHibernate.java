package com.mycompany.agenda.hibernate;

import agenda.Contacts1;
import controlador.controlador;

import java.util.List;
import java.util.Scanner;

public class AgendaHibernate {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        controlador con = new controlador();
        int opcion;

        do {
            System.out.println("\n--- MENÚ DE CONTACTOS ---");
            System.out.println("1. Crear contacto");
            System.out.println("2. Modificar contacto");
            System.out.println("3. Eliminar contacto");
            System.out.println("4. Listar contactos");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    Contacts1 nuevo = leerContacto(scanner, false);
                    con.crearContacto(nuevo);
                    break;
                case 2:
                    Contacts1 modificado = leerContacto(scanner, true);
                    con.modificarContacto(modificado);
                    break;
                case 3:
                    System.out.print("Ingrese el ID del contacto a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    scanner.nextLine();
                    Contacts1 eliminar = new Contacts1();
                    eliminar.setId(idEliminar);
                    con.eliminarContacto(eliminar);
                    break;
                case 4:
                    listar();
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 5);

        scanner.close();
    }

    public static void listar() {
        controlador con = new controlador();
        List<Contacts1> lista = con.listaDeContactos();

        for (Contacts1 contacto : lista) {
            System.out.println("\n-------------------------");
            System.out.println("Id: " + contacto.getId());
            System.out.println("Nombre: " + contacto.getFullname());
            System.out.println("Telefono: " + contacto.getPhone());
            System.out.println("Email: " + contacto.getEmail());
            System.out.println("Web Site: " + contacto.getUrl());
        }
    }

    private static Contacts1 leerContacto(Scanner scanner, boolean incluirId) {
        Contacts1 c = new Contacts1();

        if (incluirId) {
            System.out.print("ID del contacto: ");
            c.setId(scanner.nextInt());
            scanner.nextLine();
        }

        System.out.print("Nombre completo: ");
        c.setFullname(scanner.nextLine());

        System.out.print("Teléfono: ");
        c.setPhone(scanner.nextLine());

        System.out.print("Email: ");
        c.setEmail(scanner.nextLine());

        System.out.print("Sitio web: ");
        c.setUrl(scanner.nextLine());

        return c;
    }
}

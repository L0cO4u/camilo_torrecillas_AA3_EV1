
package agenda;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.io.Serializable;

/**
 *
 * @author CamiloT
 */
@Entity
@Table(name = "contacts1", catalog = "flaskcontacts", schema = "", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"email"})})
@NamedQueries({
    @NamedQuery(name = "Contacts1.findAll", query = "SELECT c FROM Contacts1 c"),
    @NamedQuery(name = "Contacts1.findById", query = "SELECT c FROM Contacts1 c WHERE c.id = :id"),
    @NamedQuery(name = "Contacts1.findByFullname", query = "SELECT c FROM Contacts1 c WHERE c.fullname = :fullname"),
    @NamedQuery(name = "Contacts1.findByPhone", query = "SELECT c FROM Contacts1 c WHERE c.phone = :phone"),
    @NamedQuery(name = "Contacts1.findByEmail", query = "SELECT c FROM Contacts1 c WHERE c.email = :email"),
    @NamedQuery(name = "Contacts1.findByUrl", query = "SELECT c FROM Contacts1 c WHERE c.url = :url")})
public class Contacts1 implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "fullname", nullable = false, length = 255)
    private String fullname;
    @Basic(optional = false)
    @Column(name = "phone", nullable = false, length = 100)
    private String phone;
    @Column(name = "email", length = 255)
    private String email;
    @Column(name = "url", length = 2000)
    private String url;

    public Contacts1() {
    }

    public Contacts1(String fullname, String phone, String email, String url) {
        this.fullname = fullname;
        this.phone = phone;
        this.email = email;
        this.url = url;
    }

    public Contacts1(Integer id, String fullname, String phone, String email, String url) {
        this.id = id;
        this.fullname = fullname;
        this.phone = phone;
        this.email = email;
        this.url = url;
    }
    
    public Contacts1(Integer id) {
        this.id = id;
    }

    public Contacts1(Integer id, String fullname, String phone) {
        this.id = id;
        this.fullname = fullname;
        this.phone = phone;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Contacts1)) {
            return false;
        }
        Contacts1 other = (Contacts1) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "agenda.Contacts1[ id=" + id + " ]";
    }
    
}

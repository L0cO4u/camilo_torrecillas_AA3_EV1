
package controlador;

import agenda.Contacts1;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import java.util.List;

/**
 *
 * @author CamiloT
 */
public class controlador {
    
    private EntityManager entityManager()
    {
             
        return conexion.conexion.getInstancia().getFabrica().createEntityManager();
    }
    
    public void crearContacto(Contacts1 contact)
    {
       EntityManager em=entityManager();
       
       em.getTransaction().begin();
       em.persist(contact);
       em.getTransaction().commit();
        System.out.println("Contacto creado!");
       
    }
    
   public void modificarContacto(Contacts1 contact)
{
    EntityManager em = entityManager();

    em.getTransaction().begin();
    em.merge(contact);
    em.getTransaction().commit();
    System.out.println("Contacto modificado!"); 
}

    public void eliminarContacto(Contacts1 contact)
{
    EntityManager em = entityManager();

    em.getTransaction().begin();
    em.remove(em.merge(contact));
    em.getTransaction().commit();
    System.out.println("Contacto eliminado!"); 
}
    
    public List<Contacts1> listaDeContactos()
    {
        Query listado = entityManager().createQuery("SELECT c FROM Contacts1 c");
        return listado.getResultList();
    }
    
    
}
